This project was generated with [Amplication](https://amplication.com)

It consists of two packages:

### [Server](./server/README.md)

### [Admin UI](./admin-ui/README.md)

### Learn more

You can learn more in the [Amplication documentation](https://docs.amplication.com/guides/getting-started).
