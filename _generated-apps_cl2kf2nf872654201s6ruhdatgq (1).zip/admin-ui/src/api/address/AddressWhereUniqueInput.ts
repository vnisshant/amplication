export type AddressWhereUniqueInput = {
  id: string;
};
