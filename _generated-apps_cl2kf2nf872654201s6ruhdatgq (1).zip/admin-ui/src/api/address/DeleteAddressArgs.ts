import { AddressWhereUniqueInput } from "./AddressWhereUniqueInput";

export type DeleteAddressArgs = {
  where: AddressWhereUniqueInput;
};
