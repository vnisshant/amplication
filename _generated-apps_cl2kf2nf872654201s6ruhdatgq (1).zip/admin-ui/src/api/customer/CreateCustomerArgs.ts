import { CustomerCreateInput } from "./CustomerCreateInput";

export type CreateCustomerArgs = {
  data: CustomerCreateInput;
};
