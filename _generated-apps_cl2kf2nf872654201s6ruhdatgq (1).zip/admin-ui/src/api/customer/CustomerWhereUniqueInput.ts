export type CustomerWhereUniqueInput = {
  id: string;
};
