import { OrderCreateInput } from "./OrderCreateInput";

export type CreateOrderArgs = {
  data: OrderCreateInput;
};
