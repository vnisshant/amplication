import { OrderWhereUniqueInput } from "./OrderWhereUniqueInput";

export type OrderFindUniqueArgs = {
  where: OrderWhereUniqueInput;
};
