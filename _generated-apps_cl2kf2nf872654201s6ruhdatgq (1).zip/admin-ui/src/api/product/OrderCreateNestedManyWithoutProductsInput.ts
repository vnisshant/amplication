import { OrderWhereUniqueInput } from "../order/OrderWhereUniqueInput";

export type OrderCreateNestedManyWithoutProductsInput = {
  connect?: Array<OrderWhereUniqueInput>;
};
