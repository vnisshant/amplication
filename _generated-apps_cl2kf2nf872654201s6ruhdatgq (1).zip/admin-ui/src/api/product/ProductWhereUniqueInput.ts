export type ProductWhereUniqueInput = {
  id: string;
};
