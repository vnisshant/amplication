export type UserWhereUniqueInput = {
  id: string;
};
