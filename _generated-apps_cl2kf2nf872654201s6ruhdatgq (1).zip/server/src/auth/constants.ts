export const INVALID_USERNAME_ERROR = "Invalid username";
export const INVALID_PASSWORD_ERROR = "Invalid password";
