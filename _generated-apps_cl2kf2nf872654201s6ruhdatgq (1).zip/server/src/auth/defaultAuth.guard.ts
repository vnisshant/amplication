import { JwtAuthGuard } from "./jwt/jwtAuth.guard";

export class DefaultAuthGuard extends JwtAuthGuard {}
